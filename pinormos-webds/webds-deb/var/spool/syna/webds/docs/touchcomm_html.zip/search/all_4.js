var searchData=
[
  ['getappinfo_0',['getAppInfo',['../classtouch__comm_1_1_touch_comm.html#a590e9b22387cd80f2113f11fcfe5e958',1,'touch_comm::TouchComm']]],
  ['getbootinfo_1',['getBootInfo',['../classtouch__comm_1_1_touch_comm.html#a1319dd510646db793393022c2774a14d',1,'touch_comm::TouchComm']]],
  ['getdatalocation_2',['getDataLocation',['../classtouch__comm_1_1_touch_comm.html#a5b666cdbf3b9edee5698fb70044119ed',1,'touch_comm::TouchComm']]],
  ['getdynamicconfig_3',['getDynamicConfig',['../classtouch__comm_1_1_touch_comm.html#a6dd0cd15bd0db6aa42c7df071d8e0e20',1,'touch_comm::TouchComm']]],
  ['geterrorcounters_4',['getErrorCounters',['../classtouch__comm_1_1_touch_comm.html#a225e12ddbbffe3938ddac4e551ea5a6a',1,'touch_comm::TouchComm']]],
  ['getfeatures_5',['getFeatures',['../classtouch__comm_1_1_touch_comm.html#a551d616f78bee81e99509ccc4f43b142',1,'touch_comm::TouchComm']]],
  ['getpacket_6',['getPacket',['../classtouch__comm_1_1_touch_comm.html#a65768fdc630bc19e7855dff0565400a7',1,'touch_comm::TouchComm']]],
  ['getreport_7',['getReport',['../classtouch__comm_1_1_touch_comm.html#a08a568c5716ccad9cfde862ed5f04f0c',1,'touch_comm::TouchComm']]],
  ['getresponse_8',['getResponse',['../classtouch__comm_1_1_touch_comm.html#ad0974be8884d85267b57ba1c66a840ca',1,'touch_comm::TouchComm']]],
  ['getslurperinfo_9',['getSlurperInfo',['../classtouch__comm_1_1_touch_comm.html#aa0bd95508d3e33a14aeb134cc5d13c98',1,'touch_comm::TouchComm']]],
  ['getstaticconfig_10',['getStaticConfig',['../classtouch__comm_1_1_touch_comm.html#aa9f7d18450aa84dd5a5e3f02ed3e85f1',1,'touch_comm::TouchComm']]],
  ['gettouchinfo_11',['getTouchInfo',['../classtouch__comm_1_1_touch_comm.html#adb8d6825e192b75edcc1fe790412747a',1,'touch_comm::TouchComm']]],
  ['gettouchreportconfig_12',['getTouchReportConfig',['../classtouch__comm_1_1_touch_comm.html#a85ce550ee4e5fa50fd00578175f2e811',1,'touch_comm::TouchComm']]]
];
