var searchData=
[
  ['unlockprivate_0',['unlockPrivate',['../classtouch__comm_1_1_touch_comm.html#a3efcc90e4a16021653a42301311c484a',1,'touch_comm::TouchComm']]]
];
