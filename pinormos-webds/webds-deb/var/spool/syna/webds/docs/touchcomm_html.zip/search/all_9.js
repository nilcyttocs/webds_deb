var searchData=
[
  ['sendcommand_0',['sendCommand',['../classtouch__comm_1_1_touch_comm.html#aa68b9a2f8bf32e49d34b77ceab269320',1,'touch_comm::TouchComm']]],
  ['setalgorithmcontrols_1',['setAlgorithmControls',['../classtouch__comm_1_1_touch_comm.html#a34ba0f2d3fde8593a6d7b00ef249e7c2',1,'touch_comm::TouchComm']]],
  ['setconfigid_2',['setConfigId',['../classtouch__comm_1_1_touch_comm.html#a9fc4c1f413b8ab985e0dd772b6333e23',1,'touch_comm::TouchComm']]],
  ['setdynamicconfig_3',['setDynamicConfig',['../classtouch__comm_1_1_touch_comm.html#a67e4f39eb3422191c62f715ed159150d',1,'touch_comm::TouchComm']]],
  ['setstaticconfig_4',['setStaticConfig',['../classtouch__comm_1_1_touch_comm.html#a284f6f08c7b3f3158c0dad2e81aa515a',1,'touch_comm::TouchComm']]],
  ['settouchreportconfig_5',['setTouchReportConfig',['../classtouch__comm_1_1_touch_comm.html#ac837cfdbb60a1062cfbb0e437f71f8ae',1,'touch_comm::TouchComm']]],
  ['startcontinuousacquisition_6',['startContinuousAcquisition',['../classtouch__comm_1_1_touch_comm.html#a0a8bb0e14e5dae7af11cc5c7aa939c46',1,'touch_comm::TouchComm']]],
  ['startsingleacquisition_7',['startSingleAcquisition',['../classtouch__comm_1_1_touch_comm.html#ab78a3d9bef94df66592067091217bf17',1,'touch_comm::TouchComm']]],
  ['stopacquisition_8',['stopAcquisition',['../classtouch__comm_1_1_touch_comm.html#a3008be8dd40b6445544c4f8f2c259664',1,'touch_comm::TouchComm']]]
];
