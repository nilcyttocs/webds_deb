var searchData=
[
  ['hardwarereset_0',['hardwareReset',['../classtouchcomm_1_1touch__comm_1_1_touch_comm.html#ac5f4f8bae9bce9ab728060ab2467cf80',1,'touchcomm::touch_comm::TouchComm']]]
];
