var searchData=
[
  ['make_0',['make',['../classtouch__comm_1_1_touch_comm.html#adb339435d59576acd8012b7d639d7baf',1,'touch_comm::TouchComm']]]
];
