var searchData=
[
  ['progdata_0',['progdata',['../namespaceftd2xx_1_1ftd2xx.html#a672a8710024a8c37587459a0a4692a29',1,'ftd2xx::ftd2xx']]]
];
