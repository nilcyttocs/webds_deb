var searchData=
[
  ['queuecommands_0',['queueCommands',['../classspi__slurper_1_1_spi_slurper.html#a747b8d8fc711f42b3fcd77b6a9a64973',1,'spi_slurper::SpiSlurper']]]
];
