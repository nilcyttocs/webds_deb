var searchData=
[
  ['open_0',['open',['../namespaceftd2xx_1_1ftd2xx.html#ab1d28e3137360d07c4f080957f243be7',1,'ftd2xx::ftd2xx']]],
  ['openex_1',['openEx',['../namespaceftd2xx_1_1ftd2xx.html#aa5edb9fe8df31d41d88dc69765092241',1,'ftd2xx::ftd2xx']]]
];
