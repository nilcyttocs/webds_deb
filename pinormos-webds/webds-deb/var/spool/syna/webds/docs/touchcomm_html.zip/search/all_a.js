var searchData=
[
  ['make_0',['make',['../classtouchcomm_1_1touch__comm_1_1_touch_comm.html#a22e3d6add503acc76362cffbec5bee18',1,'touchcomm::touch_comm::TouchComm']]],
  ['mpc_1',['mpc',['../namespacempc.html',1,'']]]
];
