var searchData=
[
  ['forcereadpacket_0',['forceReadPacket',['../classspi__slurper_1_1_spi_slurper.html#a1af9e375ef0fbbaaff03a342a3318458',1,'spi_slurper::SpiSlurper']]]
];
