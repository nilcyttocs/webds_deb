var searchData=
[
  ['identify_0',['identify',['../classtouch__comm_1_1_touch_comm.html#ad8532ac3bcf8fa4af5c88bcff9bab46d',1,'touch_comm::TouchComm']]],
  ['invalidatestate_1',['invalidateState',['../classtouch__comm_1_1_touch_comm.html#a1a94b8468ea9ca019f584776f87ac73c',1,'touch_comm::TouchComm']]]
];
