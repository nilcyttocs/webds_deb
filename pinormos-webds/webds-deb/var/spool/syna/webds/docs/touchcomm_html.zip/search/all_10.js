var searchData=
[
  ['unlockprivate_0',['unlockPrivate',['../classtouchcomm_1_1touch__comm_1_1_touch_comm.html#ab8bc7d5823099e7a4b85666bda647c0a',1,'touchcomm::touch_comm::TouchComm']]],
  ['usage_1',['Usage',['../md_usage.html',1,'']]]
];
