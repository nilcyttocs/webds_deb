var searchData=
[
  ['readflash_0',['readFlash',['../classtouch__comm_1_1_touch_comm.html#a2388ddc25be636c4378eeb96c88a7443',1,'touch_comm::TouchComm']]],
  ['readprotectedflash_1',['readProtectedFlash',['../classtouch__comm_1_1_touch_comm.html#ac7970f5f81f1173c1d8f45aa55b5288e',1,'touch_comm::TouchComm']]],
  ['readram_2',['readRam',['../classtouch__comm_1_1_touch_comm.html#a7e42015702accf3c12b48b66dbd47e68',1,'touch_comm::TouchComm']]],
  ['readregister_3',['readRegister',['../classtouch__comm_1_1_touch_comm.html#a8c24c7e56078612f114c6cc2a33c936a',1,'touch_comm::TouchComm']]],
  ['readvariable_4',['readVariable',['../classtouch__comm_1_1_touch_comm.html#a8db242639574aab9accca9effaa13251',1,'touch_comm::TouchComm']]],
  ['reflashimagefile_5',['reflashImageFile',['../classtouch__comm_1_1_touch_comm.html#a8ead6dac3e71d0fed68ba19452c76aee',1,'touch_comm::TouchComm']]],
  ['requestframe_6',['requestFrame',['../classtouch__comm_1_1_touch_comm.html#a01799821ca5c71398191daa05adbe706',1,'touch_comm::TouchComm']]],
  ['reset_7',['reset',['../classtouch__comm_1_1_touch_comm.html#aaa479339a583b7b476647a3569ea9f33',1,'touch_comm::TouchComm']]],
  ['rezero_8',['rezero',['../classtouch__comm_1_1_touch_comm.html#a76807fb869e4fd665e398cf6edd689b0',1,'touch_comm::TouchComm']]],
  ['runapplicationfirmware_9',['runApplicationFirmware',['../classtouch__comm_1_1_touch_comm.html#ab0501f568f576e32fc61650763e08e35',1,'touch_comm::TouchComm']]]
];
