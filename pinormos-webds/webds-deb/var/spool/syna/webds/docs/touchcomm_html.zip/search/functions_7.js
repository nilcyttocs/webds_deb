var searchData=
[
  ['identify_0',['identify',['../classtouchcomm_1_1touch__comm_1_1_touch_comm.html#a6dab35fc3ca9981cfe8f416e188aac59',1,'touchcomm::touch_comm::TouchComm']]],
  ['invalidatestate_1',['invalidateState',['../classtouchcomm_1_1touch__comm_1_1_touch_comm.html#acf92a2b71f7bbbb091151db6970cafb2',1,'touchcomm::touch_comm::TouchComm']]],
  ['ioctl_2',['ioctl',['../classftd2xx_1_1ftd2xx_1_1_f_t_d2_x_x.html#a264ea73e08290130346dc841afff3f8e',1,'ftd2xx::ftd2xx::FTD2XX']]],
  ['istddiimagefile_3',['isTDDIImageFile',['../classtouchcomm_1_1touch__comm_1_1_touch_comm.html#a1861655a932ae857d841d513fcf6c1bc',1,'touchcomm::touch_comm::TouchComm']]]
];
