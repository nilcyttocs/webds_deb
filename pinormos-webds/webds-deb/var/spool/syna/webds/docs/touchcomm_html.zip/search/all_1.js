var searchData=
[
  ['clearerrorcounters_0',['clearErrorCounters',['../classtouch__comm_1_1_touch_comm.html#ace6471b300efe2fc39ce1d3b05a1171c',1,'touch_comm::TouchComm']]],
  ['close_1',['close',['../classtouch__comm_1_1_touch_comm.html#a712a3e163561c87bc911c8a98b70adc8',1,'touch_comm::TouchComm']]],
  ['commitconfig_2',['commitConfig',['../classtouch__comm_1_1_touch_comm.html#ada527e8546d765ac511b7650f4e60647',1,'touch_comm::TouchComm']]],
  ['connect_3',['connect',['../classtouch__comm_1_1_touch_comm.html#a42564ed634d8c5d2421ad761fd184c4d',1,'touch_comm::TouchComm']]]
];
