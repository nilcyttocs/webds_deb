var searchData=
[
  ['detectclockdivider_0',['detectClockDivider',['../classspi__slurper_1_1_spi_slurper.html#a67897200e9fab8c94473da7bb00c2155',1,'spi_slurper::SpiSlurper']]],
  ['detectcrc_1',['detectCrc',['../classspi__slurper_1_1_spi_slurper.html#afc64bbdb5951d080808a30d833084427',1,'spi_slurper::SpiSlurper']]],
  ['disableprinting_2',['disablePrinting',['../classtouchcomm_1_1touch__comm_1_1_touch_comm.html#a9b49c0c3d5ef6791a553b82219dc1214',1,'touchcomm::touch_comm::TouchComm']]],
  ['disablereport_3',['disableReport',['../classtouchcomm_1_1touch__comm_1_1_touch_comm.html#a26b310b81240c73a4a05786ff8cf4f64',1,'touchcomm::touch_comm::TouchComm']]],
  ['disablereportbuffering_4',['disableReportBuffering',['../classtouchcomm_1_1touch__comm_1_1_touch_comm.html#a420fd6a1d07f4306f4dc25e895b40ff6',1,'touchcomm::touch_comm::TouchComm']]],
  ['docommand_5',['doCommand',['../classspi__slurper_1_1_spi_slurper.html#ab08c0331b87b83f3ca3674b3afce5549',1,'spi_slurper::SpiSlurper']]]
];
