var searchData=
[
  ['disableprinting_0',['disablePrinting',['../classtouch__comm_1_1_touch_comm.html#a4735e1db1cb7385d94fdea2e49346c82',1,'touch_comm::TouchComm']]],
  ['disablereport_1',['disableReport',['../classtouch__comm_1_1_touch_comm.html#a7c15329392d3230801ccff9452e494b5',1,'touch_comm::TouchComm']]],
  ['disablereportbuffering_2',['disableReportBuffering',['../classtouch__comm_1_1_touch_comm.html#af86300e5710a5700cb75c2f4c1de22a2',1,'touch_comm::TouchComm']]]
];
