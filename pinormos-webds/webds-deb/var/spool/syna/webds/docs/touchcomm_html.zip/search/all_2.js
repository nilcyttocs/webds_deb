var searchData=
[
  ['call_5fft_0',['call_ft',['../namespaceftd2xx_1_1ftd2xx.html#addda5566b90ecef020b564443a9eb5f1',1,'ftd2xx::ftd2xx']]],
  ['cdci_5fbackend_1',['cdci_backend',['../namespacecdci__backend.html',1,'']]],
  ['clearerrorcounters_2',['clearErrorCounters',['../classtouchcomm_1_1touch__comm_1_1_touch_comm.html#a7dcd2b635e28d56ee21f38a515ba8a80',1,'touchcomm::touch_comm::TouchComm']]],
  ['close_3',['close',['../classftd2xx_1_1ftd2xx_1_1_f_t_d2_x_x.html#a7aef8f8d59a292ea0144629fac02a600',1,'ftd2xx.ftd2xx.FTD2XX.close()'],['../classtouchcomm_1_1touch__comm_1_1_touch_comm.html#ae2f7a11386a80dda29a13c5976a3e847',1,'touchcomm.touch_comm.TouchComm.close(self)']]],
  ['commitconfig_4',['commitConfig',['../classtouchcomm_1_1touch__comm_1_1_touch_comm.html#a030484ed8fe9c01bf9327d3b03142ee8',1,'touchcomm::touch_comm::TouchComm']]],
  ['connect_5',['connect',['../classtouchcomm_1_1touch__comm_1_1_touch_comm.html#a46b378a95b29cd6fbdc2dca9f7da07c2',1,'touchcomm::touch_comm::TouchComm']]],
  ['createdeviceinfolist_6',['createDeviceInfoList',['../namespaceftd2xx_1_1ftd2xx.html#a8ac1a5206f03fccb9b598c5639767851',1,'ftd2xx::ftd2xx']]]
];
